﻿for(var i = 0; i < 48; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u34'] = 'top';