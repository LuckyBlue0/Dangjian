﻿for(var i = 0; i < 39; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

widgetIdToShowFunction['u8'] = function() {
var e = windowEvent;

if (true) {

	SetPanelState('u8', 'pd0u8','none','',500,'none','',500);

}

}

if (bIE) document.getElementById('u8').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u8'); });
else {
    document.getElementById('u8').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u8'); }, true);
    document.getElementById('u8').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u8'); }, true);
}

widgetIdToDragFunction['u8'] = function() {
var e = windowEvent;

if (true) {

	MoveWidgetBy('u8',widgetDragInfo.xDelta,widgetDragInfo.yDelta,'none',500);

}

}
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u34'] = 'center';