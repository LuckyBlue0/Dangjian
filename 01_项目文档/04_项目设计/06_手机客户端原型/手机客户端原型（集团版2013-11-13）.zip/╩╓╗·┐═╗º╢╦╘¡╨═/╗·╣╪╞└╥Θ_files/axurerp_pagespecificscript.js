﻿for(var i = 0; i < 40; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u33'] = 'top';