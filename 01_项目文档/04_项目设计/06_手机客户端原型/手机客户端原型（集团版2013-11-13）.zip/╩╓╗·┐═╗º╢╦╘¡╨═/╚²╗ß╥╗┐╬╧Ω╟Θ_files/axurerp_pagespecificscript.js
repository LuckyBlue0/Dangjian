﻿for(var i = 0; i < 46; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u34'] = 'top';