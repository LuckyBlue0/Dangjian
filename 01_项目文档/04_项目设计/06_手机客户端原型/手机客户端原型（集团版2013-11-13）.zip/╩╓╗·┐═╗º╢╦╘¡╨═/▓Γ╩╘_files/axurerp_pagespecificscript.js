﻿for(var i = 0; i < 10; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

if (bIE) document.getElementById('u6').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u6'); });
else {
    document.getElementById('u6').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u6'); }, true);
    document.getElementById('u6').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u6'); }, true);
}

widgetIdToDragFunction['u6'] = function() {
var e = windowEvent;

if (true) {

	MoveWidgetBy('u6',0,widgetDragInfo.yDelta,'none',500);

}

}

widgetIdToDragDropFunction['u6'] = function() {
var e = windowEvent;

if (IsNotOver(GetWidgetRectangles('u6'), GetWidgetRectangles('u8'))) {

	MoveWidgetTo('u6', GetNum('0'), GetNum('0'),'swing',500);

}

}
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u3'] = 'center';