﻿for(var i = 0; i < 47; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u34'] = 'center';